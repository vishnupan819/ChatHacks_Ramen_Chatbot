import React, {useState, useEffect} from "react"
import Routes from "react-router-dom"
import Home from "./components/pages/Home"

function App() {

  return (
    <section>
      <Home />
    </section>
  )
}



export default App;
